package com.whisperer.spring.service;

import com.whisperer.spring.model.AppModel;
import com.whisperer.spring.repository.AppRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppService {
    @Autowired
    private AppRepository appRepository;

    public List<AppModel> getAll() {
        return appRepository.findAll();
    }

    public void save(AppModel appModel) {
        appRepository.save(appModel);
    }
}
