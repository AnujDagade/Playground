package com.whisperer.spring.repository;

import com.whisperer.spring.model.AppModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppRepository extends JpaRepository<AppModel, Long> {

}
