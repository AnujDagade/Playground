package com.whisperer.spring.controller;

import com.whisperer.spring.model.AppModel;
import com.whisperer.spring.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AppRestController {
    @Autowired
    private AppService appService;

    @GetMapping("/get-data")
    public String getData() {
        return appService.getAll().toString();
    }

    @PostMapping("/add-data")
    public String addData(@RequestBody AppModel appModel) {
        appService.save(appModel);
        return "Data added successfully";
    }
}
