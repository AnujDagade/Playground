package com.whisperer.spring.controller;

import com.whisperer.spring.model.AppModel;
import com.whisperer.spring.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AppController {
    @Autowired
    private AppService appService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/get-data")
    public String getData(Model model) {
        model.addAttribute("data", appService.getAll() );
        return "display";
    }

    @GetMapping("/add-data")
    public String addData(Model model) {
        AppModel appModel = new AppModel();
        model.addAttribute("appModel", appModel);
        return "add";
    }
    @PostMapping("/save")
    public String saveData(AppModel appModel) {
        appService.save(appModel);
        return "redirect:/get-data";
    }

}
